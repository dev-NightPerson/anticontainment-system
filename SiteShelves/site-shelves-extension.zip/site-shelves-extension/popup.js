// Popup logic: prefill from current tab, load Site Shelves categories, then save

const DEFAULT_APP_URL = 'https://anticontainmentsystem.com/SiteShelves/index.html';

function getAppUrl() {
  return new Promise((resolve) => {
    chrome.storage.sync.get(['APP_URL'], (res) => resolve(res.APP_URL || DEFAULT_APP_URL));
  });
}

async function injectAddIntoApp(appTabId, payload) {
  const { url, title, category, newCategory } = payload;
  const [{ result }] = await chrome.scripting.executeScript({
    target: { tabId: appTabId },
    args: [url, title, category, newCategory],
    func: (url, title, category, newCategory) => {
      try {
        const read = (k, d) => { try { return JSON.parse(localStorage.getItem(k) || 'null') ?? d; } catch { return d; } };
        const write = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch {}
        };
        let sites = read('sites', []);
        let groups = read('groups', []);

        // ensure site exists
        if (!sites.some(s => s.url === url)) {
          sites.push({ url, title: title || url });
          write('sites', sites);
        }

        const eq = (a,b) => (a||'').toLowerCase() === (b||'').toLowerCase();

        // resolve/create group
        let targetId = null;
        if (newCategory) {
          const base = newCategory.trim().toLowerCase().replace(/\s+/g,'-').replace(/[^a-z0-9\-]/g,'');
          let gid = base || ('group-' + Math.random().toString(36).slice(2,7));
          const ids = new Set(groups.map(g=>g.id));
          let n=2; while (ids.has(gid)) gid = base + '-' + (n++);
          groups.push({ id: gid, name: newCategory.trim(), sites: [] });
          targetId = gid;
          write('groups', groups);
        } else if (category) {
          const byId = groups.find(g=>g.id===category);
          const byName = groups.find(g=>eq(g.name, category));
          targetId = byId? byId.id : (byName? byName.id : null);
        }
        if (!targetId && groups[0]) targetId = groups[0].id;

        if (targetId) {
          const g = groups.find(x=>x.id===targetId);
          if (g && !g.sites.includes(url)) {
            g.sites.push(url);
            write('groups', groups);
          }
        }

        // trigger UI update
        if (typeof window.refreshGrid === 'function') {
          window.refreshGrid({ skipMetadata: true });
          setTimeout(()=> window.refreshGrid(), 0);
        } else {
          location.reload();
        }
        return { ok: true, groupId: targetId };
      } catch (e) {
        return { ok: false, error: String(e) };
      }
    },
    world: 'MAIN'
  });
  return result;
}

function buildAddUrl(base, payload) {
  try {
    const u = new URL(base);
    u.searchParams.set('add', '1');
    if (payload.url) u.searchParams.set('url', payload.url);
    if (payload.title) u.searchParams.set('title', payload.title);
    if (payload.category) u.searchParams.set('category', payload.category);
    if (payload.newCategory) u.searchParams.set('newCategory', payload.newCategory);
    return u.toString();
  } catch (e) { return base; }
}

async function getActiveTab() {
  return new Promise((resolve) => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => resolve(tabs && tabs[0]));
  });
}

async function findOrOpenAppTab(appUrl) {
  // Try to find existing tab
  const urlPrefix = appUrl.replace(/[#?].*$/, '');
  const tabs = await chrome.tabs.query({ url: urlPrefix + '*' });
  if (tabs && tabs.length) return tabs[0];
  // Open in background (to keep popup open while fetching categories)
  return new Promise((resolve) => {
    chrome.tabs.create({ url: appUrl, active: false }, (tab) => {
      const tabId = tab.id;
      const listener = (updatedTabId, info) => {
        if (updatedTabId === tabId && info.status === 'complete') {
          chrome.tabs.onUpdated.removeListener(listener);
          resolve(tab);
        }
      };
      chrome.tabs.onUpdated.addListener(listener);
    });
  });
}

async function loadCategoriesFromApp(appTabId) {
  const [{ result }] = await chrome.scripting.executeScript({
    target: { tabId: appTabId },
    func: () => {
      try {
        const raw = localStorage.getItem('groups');
        const groups = raw ? JSON.parse(raw) : [];
        return groups.map(g => ({ id: g.id, name: g.name }));
      } catch (e) { return []; }
    },
    world: 'MAIN'
  });
  return result || [];
}

function populateCategorySelect(groups) {
  const sel = document.getElementById('categorySelect');
  sel.innerHTML = '';
  const optNone = document.createElement('option');
  optNone.value = '';
  optNone.textContent = 'Select a category (optional)';
  sel.appendChild(optNone);
  groups.forEach(g => {
    const opt = document.createElement('option');
    opt.value = g.id;
    opt.textContent = g.name || g.id;
    sel.appendChild(opt);
  });
  const optNew = document.createElement('option');
  optNew.value = '__new__';
  optNew.textContent = 'Create new category…';
  sel.appendChild(optNew);
}

function toggleNewCategoryRow() {
  const sel = document.getElementById('categorySelect');
  const row = document.getElementById('newCategoryRow');
  row.style.display = sel.value === '__new__' ? 'block' : 'none';
}

document.getElementById('openOptions').addEventListener('click', () => chrome.runtime.openOptionsPage());

let appTabId = null;

(async function init() {
  const appUrl = await getAppUrl();
  const active = await getActiveTab();
  // Prefill title/url
  document.getElementById('linkTitle').value = active?.title || '';
  document.getElementById('linkUrl').value = active?.url || '';
  // Ensure app tab available and fetch categories
  try {
    const appTab = await findOrOpenAppTab(appUrl);
    appTabId = appTab?.id || null;
    const cats = await loadCategoriesFromApp(appTab.id);
    populateCategorySelect(cats);
    document.getElementById('categorySelect').addEventListener('change', toggleNewCategoryRow);
    toggleNewCategoryRow();
  } catch (e) {
    // If cannot read categories, still allow manual entry
    populateCategorySelect([]);
  }
})();

document.getElementById('saveBtn').addEventListener('click', async () => {
  const appUrl = await getAppUrl();
  if (!appUrl) { chrome.runtime.openOptionsPage(); return; }
  const title = document.getElementById('linkTitle').value.trim();
  const url = document.getElementById('linkUrl').value.trim();
  const categorySel = document.getElementById('categorySelect').value;
  const newCategory = document.getElementById('newCategory').value.trim();
  const target = buildAddUrl(appUrl, {
    url,
    title,
    category: categorySel && categorySel !== '__new__' ? categorySel : '',
    newCategory: categorySel === '__new__' ? newCategory : ''
  });
  if (appTabId) {
    try {
      // Inject direct add for immediate persistence and visual update
      const res = await injectAddIntoApp(appTabId, {
        url,
        title,
        category: categorySel && categorySel !== '__new__' ? categorySel : '',
        newCategory: categorySel === '__new__' ? newCategory : ''
      });
      // Focus the app tab; if injection failed, fall back to URL param method
      // In all cases, navigate to the target URL so the app runs its own add-flow and shows the result
      await chrome.tabs.update(appTabId, { url: target, active: true });
      return;
    } catch (e) {
      // fall through to create/open via URL
    }
  }
  chrome.tabs.create({ url: target, active: true });
});
