Place PNG icons here for Chrome WebExtension manifest:
- icon-16.png
- icon-48.png
- icon-128.png

A vector source is provided at ../logo.svg. Export it to 16/48/128 PNG and place files in this folder, then (optionally) add the icons block back to manifest.json.
