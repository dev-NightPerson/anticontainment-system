// Options page: persist and open the Site Shelves app URL

function get(key) {
  return new Promise((resolve) => chrome.storage.sync.get([key], (v) => resolve(v[key])));
}
function set(obj) {
  return new Promise((resolve) => chrome.storage.sync.set(obj, () => resolve()));
}

document.getElementById('save').addEventListener('click', async () => {
  const url = document.getElementById('appUrl').value.trim();
  if (!url) return;
  await set({ APP_URL: url });
  window.alert('Saved!');
});

document.getElementById('openApp').addEventListener('click', async () => {
  const url = await get('APP_URL');
  if (url) {
    chrome.tabs.create({ url });
  } else {
    window.alert('Please set your Site Shelves URL first.');
  }
});

(async function init() {
  const url = await get('APP_URL');
  if (url) document.getElementById('appUrl').value = url;
})();
