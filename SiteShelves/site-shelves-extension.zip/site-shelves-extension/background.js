// Background service worker for Site Shelves extension
// - Adds a browser action and context menu to add current tab to Site Shelves

const DEFAULTS = {
  // Default hosted app URL (can be overridden in Options)
  APP_URL: 'https://anticontainmentsystem.com/SiteShelves/index.html',
};

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: 'add-to-site-shelves',
    title: 'Add to Site Shelves',
    contexts: ['page', 'selection', 'link']
  });
});

async function getAppUrl() {
  return new Promise((resolve) => {
    chrome.storage.sync.get(['APP_URL'], (res) => {
      resolve(res.APP_URL || DEFAULTS.APP_URL || '');
    });
  });
}

function buildAddUrl(base, payload) {
  try {
    const u = new URL(base);
    u.searchParams.set('add', '1');
    if (payload.url) u.searchParams.set('url', payload.url);
    if (payload.title) u.searchParams.set('title', payload.title);
    if (payload.category) u.searchParams.set('category', payload.category);
    return u.toString();
  } catch (e) {
    return base;
  }
}

async function openAddForTab(tab) {
  const appUrl = await getAppUrl();
  if (!appUrl) {
    chrome.runtime.openOptionsPage();
    return;
  }
  const payload = { url: tab.url || '', title: tab.title || '' };
  const target = buildAddUrl(appUrl, payload);
  chrome.tabs.create({ url: target });
}

chrome.action.onClicked.addListener((tab) => {
  openAddForTab(tab);
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === 'add-to-site-shelves') {
    openAddForTab(tab);
  }
});
